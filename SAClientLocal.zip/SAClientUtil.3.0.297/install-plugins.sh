#!/bin/bash



pushd `dirname "${BASH_SOURCE[0]}"` >& /dev/null
export APPSCAN_INSTALL_DIR=`pwd`
popd >& /dev/null


echo "--============ INSTALL APPSCAN MAVEN PLUG-IN ===============---"

echo "Install the Maven plug-in? (yes/no)"

read installMaven

if [ x${installMaven} == xyes ] || [ x${installMaven} = xy ] ; then
	mvn -version >& /dev/null

	if [ $? == 0 ] ; then

		echo .
		echo Installing the AppScan Maven plug-in ...
		echo .
		mvn  install:install-file -DgroupId=com.ibm.appscan -DartifactId=appscan-maven-plugin -Dversion=0.1.0-SNAPSHOT -Dfile="${APPSCAN_INSTALL_DIR}/plugins/maven/appscan-maven-plugin-0.1.0-SNAPSHOT.jar" -Dpackaging=jar -DpomFile="${APPSCAN_INSTALL_DIR}/plugins/maven/pom.xml"

	else

		echo .
		echo WARNING: The 'mvn' command was not recognized.
		echo .
		echo The Maven plug-in will not be installed.
		echo .

	fi

else
	echo "-Not Installing the Maven Plug-in-"
fi

echo ""
echo ""
echo ""
echo ""
echo "--============ INSTALL APPSCAN ECLIPSE PLUG-IN ===============---"

echo "Install the Eclipse plug-in? (yes/no)"

read installEclipse

if [ x${installEclipse} == xyes ] || [ x${installEclipse} = xy ] ; then

	while true; do
		echo "Enter the Eclipse install location (directory containing eclipse):"
		read eclipseInstall

		if [ -f ${eclipseInstall}/eclipse ] ; then
			break
		else
			echo .
			echo ERROR: Invalid Eclipse install location.
			echo .
		fi

	done

	echo "Eclipse Install Location: ${eclipseInstall}"
	echo .
	echo Checking for and removing previous installations ...
	echo .
	"${eclipseInstall}/eclipse" -nosplash -application org.eclipse.equinox.p2.director -uninstallIU com.ibm.appscan.eclipse.plugin.feature.feature.group -destination "${eclipseInstall}" >& /dev/null
	echo .
	echo Installing plug-in ...
	echo .

	"${eclipseInstall}/eclipse" -nosplash -application org.eclipse.equinox.p2.director -repository jar:file://"${APPSCAN_INSTALL_DIR}/plugins/eclipse/eclipse_plugin.zip!/" -installIU com.ibm.appscan.eclipse.plugin.feature.feature.group -destination "${eclipseInstall}"

	if [ $? == 0 ] ; then
		 echo "eclipse=${eclipseInstall}/eclipse" > "${APPSCAN_INSTALL_DIR}/config/eclipse.properties"
		echo "Plugin Installation successful"
	fi


else
	echo "-Not Installing the Eclipse Plug-in-"
fi

echo ""
echo "================== INSTALL FINISHED =================="
echo ""
echo "Please add the following lines to your shell resource file (.bash_profile,.shrc) and reload your shell before proceeding:"
echo ""
echo " export APPSCAN_INSTALL_DIR=`pwd`"
echo " export PATH=\${APPSCAN_INSTALL_DIR}/bin:\${PATH}"
echo " export LD_LIBRARY_PATH=\${APPSCAN_INSTALL_DIR}/bin:\${LD_LIBRARY_PATH}"
