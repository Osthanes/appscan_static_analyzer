#!/bin/bash

# ----------------------------------------------------------------------------
#  AppScan Static Analyzer Plugin Install Script for Linux/Cygwin/OSX
# ----------------------------------------------------------------------------

# ----------------------------------------------------------------------------
# THIS PRODUCT CONTAINS RESTRICTED MATERIALS OF IBM
# IBM Security AppScan Source (C) COPYRIGHT International Business Machines Corp., 2014
# All Rights Reserved * Licensed Materials - Property of IBM
# US Government Users Restricted Rights - Use, duplication or disclosure
# restricted by GSA ADP Schedule Contract with IBM Corp. 
# ----------------------------------------------------------------------------

# ----------------------------------------------------------------------------
# ENVIRONMENT VARIABLES
#
# Required:
# 	JAVA_HOME 	  - Location of a JRE or JDK home directory
# ----------------------------------------------------------------------------

pushd `dirname "${BASH_SOURCE[0]}"` >& /dev/null
export APPSCAN_INSTALL_DIR=`pwd`
popd >& /dev/null

# For Cygwin, ensure paths are in UNIX format before anything is touched.
if [[ `uname` == CYGWIN* ]] ; then
    [ -n "$JAVA_HOME" ] && JAVA_HOME=`cygpath --unix "$JAVA_HOME"`
fi

# Determine the Java command to use to start the JVM.
if [ -n "$JAVA_HOME" ] ; then
    if [ -x "$JAVA_HOME/jre/sh/java" ] ; then
        # IBM's JDK on AIX uses strange locations for the executables
        JAVACMD="$JAVA_HOME/jre/sh/java"
    else
        JAVACMD="$JAVA_HOME/bin/java"
    fi
    if [ ! -x "$JAVACMD" ] ; then
        die "ERROR: JAVA_HOME is set to an invalid directory: $JAVA_HOME

Please set the JAVA_HOME variable in your environment to match the
location of your Java installation."
    fi
else
    JAVACMD="java"
    which java >/dev/null 2>&1 || die "ERROR: JAVA_HOME is not set and no 'java' command could be found in your PATH.

Please set the JAVA_HOME variable in your environment to match the
location of your Java installation."
fi

# Run it
"$JAVACMD" -cp "${APPSCAN_INSTALL_DIR}/lib/*" com.ibm.appscan.plugin.installer.PluginInstaller

echo
